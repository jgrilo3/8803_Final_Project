To run any of the notebooks first have the following in the same directory:

-- df_prime_test.csv
-- df_prime_train.csv
-- dataloader.py
-- dataloader2.py
-- Prime_Full
-- NaiveBayes.ipynb
-- KNN.ipynb
-- CNN_untrained.ipynb
-- Resnet.ipynb
-- CNN_metadata.ipynb

Make args value equal to the location of your files above.

KNN.ipynb

1.) load the notebook
2.) run each cell block starting from the first one
3.) each block should run assuming you ran in the first block that loads the data using the dataloader.py file

NaiveBayes.ipynb

1.) load the notebook
2.) run each cell block starting from the first one
3.) each block should run assuming you ran in the first block that loads the data using the dataloader.py file

CNN_untrained.ipynb

1.) load the notebook
2.) run each cell block starting from the first one
3.) each block should run assuming you ran in the first block that loads the data using the dataloader.py file

Resnet.ipynb

1.) load the notebook
2.) run each cell block starting from the first one
3.) each block should run assuming you ran in the first block that loads the data using the dataloader.py file

